package com.suresh.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class MsDiscoveryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsDiscoveryServiceApplication.class, args);
	}

}
