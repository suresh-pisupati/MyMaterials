package com.suresh.microservice.ivs.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.suresh.microservice.ivs.entities.VersionEntity;
import com.suresh.microservice.ivs.repository.IVSRepository;

@RestController
public class IVSController {

	@Autowired
	private IVSRepository repository;

	@GetMapping("/version/{versionGuid}")
	public ResponseEntity<Optional<VersionEntity>> getVersionEntity(@PathVariable String versionGuid) {

		return ResponseEntity.ok(repository.findById(versionGuid));
	}
}
