package com.suresh.microservice.ivs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.suresh.microservice.ivs.entities.VersionEntity;

@Repository
public interface IVSRepository extends JpaRepository<VersionEntity, String> {

	@Override
	public List<VersionEntity> findAll();
}
