package com.suresh.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsBusinessrulesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsBusinessrulesServiceApplication.class, args);
	}

}
