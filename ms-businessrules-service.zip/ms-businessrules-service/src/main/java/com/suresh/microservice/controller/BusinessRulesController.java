package com.suresh.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.suresh.microservice.businessrules.entities.BusinessRulesEntity;
import com.suresh.microservice.repository.BusinessRulesRepository;

@RestController
public class BusinessRulesController {

	@Autowired
	private BusinessRulesRepository businessRulesRepository;

	@GetMapping("/api/{ruleName}")
	public ResponseEntity<List<BusinessRulesEntity>> getBusinessRules(@PathVariable String ruleName) {

		return ResponseEntity.ok(businessRulesRepository.findAllByRuleName(ruleName));
	}
}
